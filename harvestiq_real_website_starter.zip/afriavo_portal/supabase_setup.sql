-- HarvestIQ starter schema for Supabase. Run in Supabase SQL Editor.
-- Keep Row Level Security enabled. Never place service_role keys in browser code.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  referral_code text unique,
  referred_by text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "Users can view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table if not exists public.subscription_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_key text not null check (plan_key in ('free','pro','business')),
  status text not null default 'interest_only' check (status in ('interest_only','pending_payment','active','cancelled','expired')),
  provider text,
  provider_reference text,
  created_at timestamptz not null default now()
);
alter table public.subscription_requests enable row level security;
create policy "Users can view own subscription requests" on public.subscription_requests for select to authenticated using (auth.uid() = user_id);
create policy "Users can create own subscription requests" on public.subscription_requests for insert to authenticated with check (auth.uid() = user_id and status = 'interest_only');

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_user_id uuid not null references auth.users(id) on delete cascade,
  referred_user_id uuid unique references auth.users(id) on delete set null,
  referral_code text not null,
  status text not null default 'registered' check (status in ('registered','qualified','rewarded','rejected')),
  created_at timestamptz not null default now()
);
alter table public.referrals enable row level security;
create policy "Users can view referrals they sent" on public.referrals for select to authenticated using (auth.uid() = referrer_user_id);

-- Auth user -> profile row. Referral attribution and rewards should be validated server-side.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, referral_code, referred_by)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name',''),
    'HIQ-' || upper(substr(replace(new.id::text,'-',''),1,8)),
    nullif(new.raw_user_meta_data ->> 'referral_code','')
  ) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
